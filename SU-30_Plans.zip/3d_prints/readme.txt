Normal PLA will do just fine, but for maximal weight savins you can use ABS and foaming light weight.


Mirrored parts are not included. "+M" in the name means a mirrored part is also required.
